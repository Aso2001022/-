//難易度
let levelOfDifficulty = document.getElementById("levelOfDifficulty").textContent;
console.log(levelOfDifficulty);

//問題範囲
let range = 0;

//最小値(範囲)
let min = 1;

//図鑑番号
let id = 0;

if( levelOfDifficulty == 3 ){

    range = 151;

}else if( levelOfDifficulty == 2 ){

    range = 99;

}else{

    range = 49;

}

console.log(range);

//最大値(範囲)
let max = range;

min = Math.ceil(min);
max = Math.ceil(max);
id = Math.floor(Math.random() * (max - min + 1) + min);
console.log( id );

//図鑑番号(HTML)
let No = document.getElementById("id").textContent = id;
console.log(No);

//フォーム図鑑番号
let Num = document.getElementById("Num").value = id;






