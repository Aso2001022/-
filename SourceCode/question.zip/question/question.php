<?php
    session_start();
?>

<?php

    

?>

<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Question</title>
    <meta name="description" content="answerPage">
    <link rel="stylesheet" href="./css/style.css">
</head>
<body>

    <div id="silhouetteArea">
        <div id="square">
            <img src="a" id="silhouette">
            <img src="./img/モンスターボール (1).png" id="ball1">
            <img src="./img/モンスターボール (1).png" id="ball2">
            <img src="./img/モンスターボール (1).png" id="ball3">
            <img src="./img/モンスターボール (1).png" id="ball4">
        </div>
    </div>

    <div id="iconArea">
        <img src="./img/20221012114049446_500x200.png" id="icon">
    </div>

    <div id="answerArea">
        <p id="text">？？？？</p>
        <input type="text" id="textBox" maxlength="6" autofocus>
        <img src="./img/toAnswer.png" id="toAnswer">
    </div>

    <script src="./js/poke.js"></script>

</body>
</html>